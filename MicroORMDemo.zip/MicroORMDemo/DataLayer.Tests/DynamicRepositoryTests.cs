﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MicroOrmDemo.DataLayer.Tests
{
    [TestClass]
    [DeploymentItem("Simple.Data.Ado.dll")]
    [DeploymentItem("Simple.Data.SqlServer.dll")]
    public class DynamicRepositoryTests
    {
        [TestMethod]
        public void Get_all_should_return_6_results()
        {
            // arrange
            var repository = CreateRepository();

            // act
            var contacts = repository.GetAll();

            // assert
            Assert.IsNotNull(contacts);
            Assert.AreEqual(6, contacts.Count);
        }

        static int id;

        [TestMethod]
        public void Insert_should_assign_identity_to_new_entity()
        {
            // arrange
            var repository = CreateRepository();
            dynamic contact = new
            {
                FirstName = "Joe",
                LastName = "Blow",
                Email = "joe.blow@gmail.com",
                Company = "Microsoft",
                Title = "Developer"
            };

            // act
            var addedContact = repository.Add(contact);

            // assert
            Assert.AreNotEqual(0, addedContact.ID, "ID should not be 0 because Identity should have been assigned by database.");
            Console.WriteLine("New ID: " + addedContact.ID);
            id = (int)addedContact.ID;
        }

        [TestMethod]
        public void Find_should_retrieve_existing_entity()
        {
            // arrange
            var repository = CreateRepository();

            // act
            var contact = repository.Find(id);

            // assert
            Assert.IsNotNull(contact);
            Assert.AreEqual(id, contact.Id);
            Assert.AreEqual("Joe", contact.FirstName);
            Assert.AreEqual("Blow", contact.LastName);
            Assert.AreEqual("joe.blow@gmail.com", contact.Email);
        }

        [TestMethod]
        public void Modify_should_update_existing_entity()
        {
            // arrange
            var repository = CreateRepository();

            // act
            var contact = repository.Find(id);
            contact.FirstName = "Bob";
            repository.Update(contact);

            // create a new repository for verification purposes
            var repository2 = CreateRepository();
            var modifiedContact = repository2.Find(id);

            // assert
            Assert.AreEqual("Bob", modifiedContact.FirstName);
        }

        [TestMethod]
        public void Delete_should_remove_entity()
        {
            // arrange
            var repository = CreateRepository();

            // act
            repository.Remove(id);

            // create a new repository for verification purposes
            var repository2 = CreateRepository();
            var deletedEntity = repository2.Find(id);

            // assert
            Assert.IsNull(deletedEntity);
        }


        //private static Massive.ContactRepository CreateRepository()
        //{
        //    return new Massive.ContactRepository();
        //}

        private static SimpleData.ContactRepository CreateRepository()
        {
            return new SimpleData.ContactRepository();
        }


    }
}
