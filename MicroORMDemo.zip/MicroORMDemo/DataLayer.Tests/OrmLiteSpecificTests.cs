﻿using System;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using FluentAssertions;

namespace MicroOrmDemo.DataLayer.Tests
{
    [TestClass]
    public class OrmLiteSpecificTests
    {
        [TestMethod]
        public void Sql_IN_should_produce_correct_results()
        {
            // arrange
            var repository = new OrmLite.ContactRepository();

            // act
            var contacts = repository.GetContactsByIds(1, 3, 4);

            // assert
            contacts.Count.Should().Be(3);
        }

        [TestMethod]
        public void Sql_inequality_should_produce_correct_results()
        {
            // arrange
            var repository = new OrmLite.ContactRepository();

            // act
            var contacts = repository.GetContactsByIdRange(2, 5);

            // assert
            contacts.Count.Should().Be(4);
        }

        [TestMethod]
        public void Sql_starts_with_should_produce_correct_results()
        {
            // arrange
            var repository = new OrmLite.ContactRepository();

            // act
            var contacts = repository.GetContactsByLastNameStartsWith("J");

            // assert
            contacts.Count.Should().Be(2);
        }

        [TestMethod]
        public void Sql_contains_should_produce_correct_results()
        {
            // arrange
            var repository = new OrmLite.ContactRepository();

            // act
            var contacts = repository.GetContactsByLastNameContains("ame");

            // assert
            contacts.Count.Should().Be(1);
            contacts.First().FirstName.Should().Be("LaBron");
        }
    }
}
