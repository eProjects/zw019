﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using PetaPoco;
using FluentAssertions;

namespace MicroOrmDemo.DataLayer.Tests
{
    [TestClass]
    public class PetaPocoSpecificTests
    {
        [TestMethod]
        public void Paging_should_return_correct_results()
        {
            // arrange
            var repository = new PetaPoco.ContactRepository();

            // act
            Page<Contact> pagedResult = repository.GetAllPaged(2, 2);

            // assert
            Assert.IsNotNull(pagedResult);
            Assert.AreEqual(2, pagedResult.Items.Count);
            Assert.AreEqual("Bryant", pagedResult.Items[0].LastName);
            Assert.AreEqual("Durant", pagedResult.Items[1].LastName);
            Assert.AreEqual(6, pagedResult.TotalItems);
            Assert.AreEqual(3, pagedResult.TotalPages);
        }

        [TestMethod]
        public void Compound_where_clause_should_return_correct_results()
        {
            // arrange
            var repository = new PetaPoco.ContactRepository();

            // act
            var contacts = repository.GetByLastNameAndTitle("Paul", "CP3");

            // assert
            contacts.Should().NotBeNull();
            contacts.Count.Should().Be(1);
            contacts[0].FirstName.Should().Be("Chris");
            contacts[0].LastName.Should().Be("Paul");
        }
    }
}
