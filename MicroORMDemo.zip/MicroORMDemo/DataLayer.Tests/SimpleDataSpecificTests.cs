﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MicroOrmDemo.DataLayer.Tests
{
    [TestClass]
    [DeploymentItem("Simple.Data.Ado.dll")]
    [DeploymentItem("Simple.Data.SqlServer.dll")]
    public class SimpleDataSpecificTests
    {
        [TestMethod]
        public void Get_all_should_return_6_results()
        {
            // arrange
            var repository = new SimpleData.ContactRepository();

            // act
            var contacts = repository.GetAllSelectedColumns();

            // assert
            Assert.IsNotNull(contacts);
            Assert.AreEqual(1, contacts.Count);
            Assert.AreEqual("Jordan", contacts[0].LastName);
            //Assert.AreEqual("MVP", contacts[0].Title);
        }


        [TestMethod]
        public void Count_should_return_2_results()
        {
            // arrange
            var repository = new SimpleData.ContactRepository();

            // act
            var count = repository.GetAddressCountByCity("Chicago");

            // assert
            Assert.AreEqual(2, count);
        }

        [TestMethod]
        public void Distinct_address_types_should_return_2()
        {
            // arrange
            var repository = new SimpleData.ContactRepository();

            // act
            var addressTypes = repository.GetDistinctAddressTypes();

            // assert
            Assert.AreEqual(2, addressTypes.Count);
            Assert.AreEqual("Home", addressTypes[0].AddressType);
            Assert.AreEqual("Work", addressTypes[1].AddressType);
        }

        [TestMethod]
        public void Get_full_address_should_include_state_name()
        {
            // arrange
            var repository = new SimpleData.ContactRepository();
            
            // act
            var address = repository.GetFullAddress(1);

            // assert
            Assert.IsNotNull(address);
            Assert.AreEqual("123 Main Street", address.StreetAddress);
            Assert.AreEqual("Illinois", address.States.StateName);
        }
    }
}
