﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Peta = PetaPoco;

namespace MicroOrmDemo.DataLayer
{
    //[ServiceStack.DataAnnotations.Alias("Addresses")]
    [Peta.TableName("Addresses")]
    [Peta.PrimaryKey("Id")]
    public class Address
    {
        //[ServiceStack.DataAnnotations.AutoIncrement]
        public int Id { get; set; }

        //[ServiceStack.OrmLite.ForeignKey(typeof(Contact), OnDelete = "CASCADE")]
        public int ContactId { get; set; }
        public string AddressType { get; set; }
        public string StreetAddress { get; set; }
        public string City { get; set; }
        public int StateId { get; set; }
        public string PostalCode { get; set; }

        //[ServiceStack.DataAnnotations.Ignore]
        [Peta.Ignore]
        internal bool IsNew
        {
            get
            {
                return this.Id == default(int);
            }
        }

        //[ServiceStack.DataAnnotations.Ignore]
        [Peta.Ignore]
        public bool IsDeleted { get; set; }
    }
}
