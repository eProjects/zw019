﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Peta = PetaPoco;

namespace MicroOrmDemo.DataLayer
{
    //[ServiceStack.DataAnnotations.Alias("Contacts")]
    [Peta.TableName("Contacts")]
    [Peta.PrimaryKey("Id")]
    public class Contact
    {
        public Contact()
        {
            this.Addresses = new List<Address>();
        }

        //[ServiceStack.DataAnnotations.AutoIncrement]
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Company { get; set; }
        public string Title { get; set; }

        //[ServiceStack.DataAnnotations.Ignore]
        [Peta.Ignore]
        public List<Address> Addresses { get; set; }

        //[ServiceStack.DataAnnotations.Ignore]
        [Peta.Ignore]
        public bool IsNew
        {
            get
            {
                return this.Id == default(int);
            }
        }
    }
}
