﻿using Massive;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MicroOrmDemo.DataLayer.Massive
{
    public class Contacts : DynamicModel
    {
        public Contacts()
            : base("contactsDB", "Contacts", "Id")
        {
        }

        public override void Validate(dynamic item)
        {
            this.ValidatesPresenceOf(item.FirstName);
            this.ValidatesPresenceOf(item.LastName);
        }


        public override bool BeforeSave(dynamic item)
        {
            Console.WriteLine("About to save...");
            return true;
        }

        public override void Inserted(dynamic item)
        {
            Console.WriteLine("Just inserted: {0} {1}", item.FirstName, item.LastName);
        }

        public override void Updated(dynamic item)
        {
            Console.WriteLine("Just updated: {0} {1}", item.FirstName, item.LastName);
        }
    }
}
