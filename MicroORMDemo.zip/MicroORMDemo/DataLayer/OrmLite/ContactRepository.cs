﻿using ServiceStack.OrmLite;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;

namespace MicroOrmDemo.DataLayer.OrmLite
{
    public class ContactRepository : IContactRepository
    {
        private IDbConnection db = CreateDbConnection();

        public Contact Find(int id)
        {
            return this.db.GetByIdOrDefault<Contact>(id);
            //return this.db.Where<Contact>(new { Id = id }).SingleOrDefault();
            //return this.db.Where<Contact>(c => c.Id == id).SingleOrDefault();
            //return this.db.SingleWhere<Contact>("Id", id);
            //return this.db.QuerySingle<Contact>(new { Id = id });
        }

        public List<Contact> GetAll()
        {
            //return this.db.Query<Contact>("SELECT * FROM Contacts");
            return this.db.Select<Contact>();
        }

        public Contact Add(Contact contact)
        {
            this.db.Insert(contact);
            contact.Id = (int)this.db.GetLastInsertId();
            return contact;
        }

        public Contact Update(Contact contact)
        {
            this.db.Update(contact);
            return contact;
        }

        public void Remove(int id)
        {
            this.db.DeleteById<Contact>(id);
        }

        public Contact GetFullContact(int id)
        {
            return this.Find(id);
            //return this.db.SqlList<Contact>("EXEC GetContact @Id", new { id }).SingleOrDefault();
            
            

            //var contact = this.db.GetByIdOrDefault<Contact>(id);
            //var addresses = this.db.Where<Address>(a => a.ContactId == id);

            //if (contact != null && addresses != null)
            //{
            //    contact.Addresses.AddRange(addresses);
            //}

            //return contact;
        }

        public void Save(Contact contact)
        {
            if (contact.IsNew)
            {
                this.Add(contact);
            }
            else
            {
                this.Update(contact);
            }

            //using (var txScope = new TransactionScope())
            //{
            //    if (contact.IsNew)
            //    {
            //        this.Add(contact);
            //    }
            //    else
            //    {
            //        this.Update(contact);
            //    }

            //    foreach (var addr in contact.Addresses.Where(a => !a.IsDeleted))
            //    {
            //        addr.ContactId = contact.Id;
            //        this.db.Save(addr);
            //    }

            //    foreach (var addr in contact.Addresses.Where(a => a.IsDeleted))
            //    {
            //        this.db.DeleteById<Address>(addr.Id);
            //    }

            //    txScope.Complete();
            //}
        }

        public void Initialize()
        {
            this.db.DropAndCreateTable<Contact>();
            //this.db.DropAndCreateTable<Address>();
        }



        public List<Contact> GetContactsByIds(params int[] ids)
        {
            return this.db.Select<Contact>(c => Sql.In(c.Id, ids));
        }

        public List<Contact> GetContactsByIdRange(int start, int end)
        {
            return this.db.Select<Contact>(c => c.Id >= start && c.Id <= end);
        }

        public List<Contact> GetContactsByLastNameStartsWith(string lastName)
        {
            return this.db.Select<Contact>(c => c.LastName.StartsWith(lastName));
        }

        public List<Contact> GetContactsByLastNameContains(string lastName)
        {
            return this.db.Select<Contact>(c => c.LastName.Contains(lastName));
        }


        #region Private Methods

        private static IDbConnection CreateDbConnection()
        {
            var dbFactory = new OrmLiteConnectionFactory(ConfigurationManager.ConnectionStrings["contactsDBOrmLiteDefault"].ConnectionString, SqlServerDialect.Provider);
            var db = dbFactory.OpenDbConnection();
            return db;
        }

        #endregion
    }
}
