﻿using PetaPoco;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;

namespace MicroOrmDemo.DataLayer.PetaPoco
{
    public class ContactRepository : IContactRepository
    {
        private Database db = new Database("contactsDB");

        public Contact Find(int id)
        {
            return this.db.SingleOrDefault<Contact>("WHERE Id = @0", id);
        }

        public List<Contact> GetAll()
        {
            //return this.db.Query<Contact>("SELECT * FROM Contacts").ToList();
            return this.db.Query<Contact>("").ToList();
        }

        public List<contactsDB.Contact> GetAllGenerated()
        {
            //return this.db.Query<Contact>("SELECT * FROM Contacts").ToList();
            return this.db.Query<contactsDB.Contact>("").ToList();
        }

        public Contact Add(Contact contact)
        {
            //this.db.Insert("Contacts", "Id", contact);
            this.db.Insert(contact);
            return contact;
        }

        public Contact Update(Contact contact)
        {
            //this.db.Update("Contacts", "Id", contact);
            this.db.Update(contact);
            return contact;
        }

        public void Remove(int id)
        {
            this.db.Delete<Contact>(id);
        }

        public Contact GetFullContact(int id)
        {
            var contact = this.Find(id);
            var addresses = this.db.Query<Address>("WHERE ContactId = @0", id).ToList();

            if (contact != null && addresses != null)
            {
                contact.Addresses.AddRange(addresses);
            }

            return contact;
        }

        public void Save(Contact contact)
        {
            using (var txScope = new TransactionScope())
            {
                if (contact.IsNew)
                {
                    this.Add(contact);
                }
                else
                {
                    this.Update(contact);
                }

                foreach (var addr in contact.Addresses.Where(a => !a.IsDeleted))
                {
                    addr.ContactId = contact.Id;
                    this.db.Save(addr);
                }

                foreach (var addr in contact.Addresses.Where(a => a.IsDeleted))
                {
                    this.db.Delete<Address>(addr.Id);
                }

                txScope.Complete();
            }
        }



        public Page<Contact> GetAllPaged(int currentPage, int pageSize)
        {
            return this.db.Page<Contact>(currentPage, pageSize, "");
        }

        public List<Contact> GetByLastNameAndTitle(string lastName, string title)
        {
            var sql = Sql.Builder
                .Append("WHERE LastName = @lastName AND Title = @title",
                new
                {
                    lastName = lastName,
                    title = title
                });

            var contacts = this.db.Query<Contact>(sql).ToList();

            Console.WriteLine("LastCommand: " + this.db.LastCommand);

            return contacts;
        }
    }
}
