﻿using Simple.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MicroOrmDemo.DataLayer.SimpleData
{
    public class ContactRepository
    {
        private dynamic db = Database.OpenNamedConnection("contactsDB");

        public dynamic Find(int id)
        {
            dynamic contact = this.db.Contacts.FindById(id);
            return contact;
        }

        public List<dynamic> GetAll()
        {
            return this.db.Contacts.All();
        }

        public List<dynamic> GetAllSelectedColumns()
        {
            //return this.db.Contacts.All().Select(db.Contacts.FirstName, db.Contacts.LastName);
            return this.db.Contacts.FindAllById(1).Select(db.Contacts.FirstName, db.Contacts.LastName);
        }

        public int GetAddressCountByCity(string cityName)
        {
            return this.db.Addresses.GetCount(db.Addresses.City == cityName);
        }

        public List<dynamic> GetDistinctAddressTypes()
        {
            return this.db.Addresses.All().Select(db.Addresses.AddressType.Distinct());
        }

        public dynamic GetFullAddress(int id)
        {
            return this.db.Addresses.WithStates().Get(id);
        }
        

        public dynamic Add(dynamic contact)
        {
            var addedContact = this.db.Contacts.Insert(contact);
            return addedContact;
        }

        public dynamic Update(dynamic contact)
        {
            this.db.Contacts.Update(contact);
            return contact;
        }

        public void Remove(int id)
        {
            this.db.Contacts.DeleteById(id);
        }
    }

    public class ContactRepositoryStatic : IContactRepository
    {
        private dynamic db = Database.OpenNamedConnection("contactsDB");

        public Contact Find(int id)
        {
            Contact contact = this.db.Contacts.FindById(id);
            return contact;
        }

        public List<Contact> GetAll()
        {
            return this.db.Contacts.All().ToList<Contact>();
        }

        public Contact Add(Contact contact)
        {
            Contact addedContact = this.db.Contacts.Insert(contact);
            contact.Id = addedContact.Id;
            return addedContact;
        }

        public Contact Update(Contact contact)
        {
            this.db.Contacts.Update(contact);
            return contact;
        }

        public void Remove(int id)
        {
            this.db.Contacts.DeleteById(id);
        }

        public Contact GetFullContact(int id)
        {
            throw new NotImplementedException();
        }

        public void Save(Contact contact)
        {
            throw new NotImplementedException();
        }
    }

}
