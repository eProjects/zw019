﻿using System;

namespace MicroOrmDemo.DataLayer
{
    public class State
    {
        public int Id { get; set; }
        public string StateName { get; set; }
    }
}
