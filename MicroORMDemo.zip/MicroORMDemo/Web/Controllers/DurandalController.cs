using System.Web.Mvc;

namespace MicroORMDemo.Web.Controllers {
  public class DurandalController : Controller {
    public ActionResult Index() {
      return View();
    }
  }
}