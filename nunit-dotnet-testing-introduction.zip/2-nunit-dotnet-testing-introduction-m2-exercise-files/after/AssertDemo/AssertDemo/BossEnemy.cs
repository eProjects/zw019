﻿namespace AssertDemo
{
    public class BossEnemy : Enemy
    {
        public int ExtraPower
        {
            get { return 42; }
        }
    }
}
