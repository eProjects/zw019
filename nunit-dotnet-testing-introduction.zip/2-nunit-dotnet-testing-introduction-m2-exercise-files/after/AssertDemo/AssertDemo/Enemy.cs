﻿namespace AssertDemo
{
    public class Enemy
    {
    }
}