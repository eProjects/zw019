﻿namespace AssertDemo
{
    public class NameJoiner
    {
        public string Join(string firstName, string lastName)
        {
            return firstName + " " + lastName;
        }
    }
}
