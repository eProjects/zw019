﻿namespace AssertDemo
{
    public class NormalEnemy : Enemy
    {
    }
}