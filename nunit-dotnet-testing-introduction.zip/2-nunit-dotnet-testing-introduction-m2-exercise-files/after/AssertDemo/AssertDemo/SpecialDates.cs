﻿namespace AssertDemo
{
    public enum SpecialDates
    {
        NewMillennium
    }
}